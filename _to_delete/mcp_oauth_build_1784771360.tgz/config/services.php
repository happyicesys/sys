<?php

return [

    // Hosts allowed as OAuth redirect targets for MCP Dynamic Client
    // Registration (subdomains included). Loopback (localhost/127.0.0.1)
    // is always allowed for mcp-remote. Extend via MCP_OAUTH_REDIRECT_HOSTS.
    'mcp_oauth' => [
        'redirect_hosts' => env('MCP_OAUTH_REDIRECT_HOSTS', 'claude.ai,claude.com,anthropic.com'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
        'scheme' => 'https',
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'ai' => [
        'driver' => env('AI_DRIVER', 'openai'), // 'google' or 'openai'
    ],

    'google' => [
        'api_key' => env('GOOGLE_API_KEY'),
        'base_uri' => env('GOOGLE_BASE_URI', 'https://generativelanguage.googleapis.com/v1beta/models'),
        'vend_temp' => [
            'enabled' => env('VEND_TEMP_AI_ENABLED', false),
            'model' => env('VEND_TEMP_AI_MODEL', 'gemini-1.5-flash'),
            'window_minutes' => env('VEND_TEMP_AI_WINDOW_MINUTES', 45),
            'max_samples' => env('VEND_TEMP_AI_MAX_SAMPLES', 30),
        ],
    ],

    'openai' => [
        'api_key' => env('OPENAI_API_KEY'),
        'base_uri' => env('OPENAI_BASE_URI', 'https://api.openai.com/v1'),
        'vend_temp' => [
            'enabled' => env('VEND_TEMP_AI_ENABLED', false),
            'model' => env('VEND_TEMP_AI_MODEL', 'gpt-4o-mini'),
            'window_minutes' => env('VEND_TEMP_AI_WINDOW_MINUTES', 45),
            'max_samples' => env('VEND_TEMP_AI_MAX_SAMPLES', 30),
        ],
    ],

];
